﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculador_Simples_Paulo_Henrique
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int Num1, Num2;

            Num1 = int.Parse(textBox2.Text);
            Num2 = int.Parse(textBox1.Text);

            label3.Text = (Num1 + Num2).ToString();
        }
    }
}
